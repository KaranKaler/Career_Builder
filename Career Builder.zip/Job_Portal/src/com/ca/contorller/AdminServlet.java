package com.ca.contorller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name="AdminServlet",urlPatterns={"/AdminServlet"})
public class AdminServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		String name = request.getParameter("EmailId");
		String pass = request.getParameter("password");
		PrintWriter out = response.getWriter();
		try{
		if(name.equals("admin@admin.ca") && pass.equals("admin"))
		{
			HttpSession session=request.getSession();  
	        session.setAttribute("uname",name);
	        response.sendRedirect("views/Admin/Admin.jsp");
		}
		else
		{
			out.println("you are not admin");
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}