package com.ca.contorller;

import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ca.dto.Compreg;
import com.ca.service.CloginService;


@WebServlet(name="CloginServlet",urlPatterns={"/CloginServlet"})
public class CloginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

	 String EmailId = request.getParameter("EmailId");	
	 String password = request.getParameter("password");
	 CloginService loginService = new CloginService();
	 boolean result = loginService.authenticateUser(EmailId, password);
	 Compreg reg = loginService.getUserByUserId(EmailId);
	 if(result == true){
		 request.getSession().setAttribute("register", reg);		
		 response.sendRedirect("views/company/chome.jsp");
		 
		 //Setting logged email in HttpSession named "Clogmail"
		 HttpSession context = request.getSession();
		 context.setAttribute("Clogmail", EmailId);
	 }
	 else{
		 //If EmailId and password not matched send redirect to error page name="error.jsp"
		 response.sendRedirect("error.jsp");
	 }
  }	
}
