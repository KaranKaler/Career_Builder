package com.ca.contorller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ca.dto.CompSec;
import com.ca.service.SecService;


@WebServlet(name="Compsecurity",urlPatterns="/Compsecurity")
public class Compsecurity extends HttpServlet{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		String SQ1 = request.getParameter("Ques1");
		String Ans1 = request.getParameter("Ans1");
		String SQ2 = request.getParameter("Ques2");
		String Ans2 = request.getParameter("Ans2");
		//session for company registration
		HttpSession context = request.getSession();
		String n = (String) context.getAttribute("cmail");
		CompSec sec = new CompSec(SQ1,Ans1,SQ2,Ans2,n);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		SecService service = new SecService();
		try{
		boolean result = service.checkmail(sec);
		out.println("<html>");
		 out.println("<head>");		
		 out.println("<title>Registration Successful</title>");		
		 out.println("</head>");
		 out.println("<body>");
		 out.println("<center>");
		 if(result){
			 out.println("<h1>Thanks for Registering with us :</h1>");
			 out.println("To login with new UserId and Password<a href=views/company/clogin.jsp>Click here</a>");
			 context.invalidate();
		 }else{
			 out.println("<h1>Registration Failed</h1>");
			 out.println("To try again<a href=views/company/cregister.jsp>Click here</a>");
		 }
		 out.println("</center>");
		 out.println("</body>");
		 out.println("</html>");
	 } finally {		
		 out.close();
	 }
   }
 }
	
