package com.ca.contorller;

import java.io.IOException;  
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ca.dto.CompSec;
import com.ca.dto.CompanyInfo;
import com.ca.dto.Compreg;
import com.ca.service.CregisterService;
import com.ca.service.InfoService;
import com.ca.service.SecService;

@WebServlet(name="CregisterServlet",urlPatterns={"/CregisterServlet"})
public class CregisterServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String EmailId = request.getParameter("EmailId");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String State = request.getParameter("state");
		String City = request.getParameter("City");
		String ContactPerson = request.getParameter("ContactPerson");
		String Pin = request.getParameter("Pin");
		String Contactno = request.getParameter("Contactno");
		String Industry = request.getParameter("Industry");
		
		Compreg reg =new Compreg(EmailId,password,name,State,City,ContactPerson,Pin,Contactno,Industry);
		CompSec sec = new CompSec();
		CompanyInfo info = new CompanyInfo();
		InfoService service = new InfoService();
		SecService service2 = new SecService();
		
		 try {	
			 CregisterService cregisterService = new CregisterService();
			 boolean result = cregisterService.register(reg);
			 sec.setReg(reg);
			 info.setReg(reg);
			 service.setupdate(info);
			 service2.setupdate(sec);
			 if(result){
				 response.sendRedirect("views/company/Compinfo.jsp");
				 //session for company registration
				 HttpSession context = request.getSession();
				 context.setAttribute("cmail",EmailId );
			 }else{
				 out.println("<h1>Registration Failed</h1>");
				 out.println("To try again<a href=views/company/cregister.jsp>Click here</a>");
			 }
			} finally {		
			 out.close();
		 }
	}
		
}
