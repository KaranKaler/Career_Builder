package com.ca.contorller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ca.dto.CompanyInfo;
import com.ca.service.InfoService;


@WebServlet(name="InfoServlet", urlPatterns="/InfoServlet")
public class InfoServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
	{
		String Information = request.getParameter("INformation");
		// session for company mail registration
		HttpSession context =request.getSession();
		String n = (String) context.getAttribute("cmail");
		CompanyInfo info = new CompanyInfo(Information,n);
		InfoService service = new InfoService();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		boolean result = service.checkmail(info);
		 if(result == true){
			 response.sendRedirect("views/company/CompSec.jsp");
		 }
		 else{
			 out.println("<h1>Registration Failed</h1>");
			 out.println("To try again<a href=views/company/CompSec.jsp>Click here</a>");
		 }
	
	}
	
}