package com.ca.contorller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ca.dto.JobPost;
import com.ca.service.Postservice;

@WebServlet(name="Jobpost", urlPatterns="/Jobpost")
public class Jobpost extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException
	{
		String Profile = request.getParameter("profile");
		String Company = request.getParameter("Cname");
		String Place = request.getParameter("Place");
		String Experience = request.getParameter("experiance");
		String Salary = request.getParameter("Salary");
		String Pin = request.getParameter("Pin_code");
		String Description = request.getParameter("Description");
		String Industry = request.getParameter("Industry");
		HttpSession context = request.getSession();
		String n = (String) context.getAttribute("Clogmail");
		
		JobPost post = new JobPost(Profile,Company,Place,Experience,Salary,Pin,Description,Industry,n);
		Postservice service = new Postservice();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		boolean result = service.checkmail(post);
		 if(result == true){
			 response.sendRedirect("views/company/chome.jsp");
		 }
		 else{
			 out.println("<h1>jobpost failedFailed</h1>");
			 out.println("To try again<a href=views/company/jobpost.jsp>Click here</a>");
		 }
		
	}
}
