package com.ca.contorller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ca.dto.Profile;
import com.ca.dto.Registration;
import com.ca.service.PService;
import com.ca.service.RegisterService;

public class RegisterServlet extends HttpServlet{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String firstName = request.getParameter("firstName");
		 String lastName = request.getParameter("lastName"); 
		 String email = request.getParameter("email");
		 String password = request.getParameter("password");
		 String Gender = request.getParameter("gender");
		 String Skills = request.getParameter("Skills");
		 String Location = request.getParameter("Location");
		 String Industry = request.getParameter("Industry");
		 
		 
		 Registration register = new Registration(email,firstName,lastName,password,Location, Skills, Gender, Industry);
		 Profile profile = new Profile(register);

		 PService service = new PService();

		  try {	
			 RegisterService registerService = new RegisterService();
			 boolean result = registerService.register(register);
			 if(result){
				 service.setupdate(profile);

				 response.sendRedirect("views/student/profile.jsp");
				 HttpSession session = request.getSession();
				 session.setAttribute("email", email);

			 }else{
				 out.println("<h1>Registration Failed</h1>");
				 out.println("To try again<a href=register.jsp>Click here</a>");
			 }
			 
		 } finally {		
			 out.close();
		 }
	}
}