package com.ca.contorller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ca.dto.Profile;
import com.ca.service.PService;

@WebServlet(name="Sprofile",urlPatterns={"/Sprofile"})
public class Sprofile extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		
		String DOB=request.getParameter("DOB");
		String Qual=request.getParameter("Qual");
		String College= request.getParameter("College");
		String Year=request.getParameter("Year");
		String University=request.getParameter("University");
		
		
		HttpSession context = request.getSession();
		String n = (String) context.getAttribute("email");
		
		Profile profile = new Profile(DOB,Qual,College,Year,University,n);
						
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		PService service = new PService();
		boolean result = service.checkmail(profile);
		 
		 out.println("<html>");
		 out.println("<head>");		
		 out.println("<title>Registration Successful</title>");		
		 out.println("</head>");
		 out.println("<body>");
		 out.println("<center>");
		if(result){
			 out.println("<h1>Thanks for Registering with us :</h1>");
			 out.println("To login with new UserId and Password <a href=Login.jsp>Click here</a>");
			 context.invalidate();
		 }else{
			 out.println("<h1>Registration Failed</h1>");
			 out.println("To try again<a href=register.jsp>Click here</a>");
		 }
		 out.println("</center>");
		 out.println("</body>");
		 out.println("</html>");
	 }
	
	
}	