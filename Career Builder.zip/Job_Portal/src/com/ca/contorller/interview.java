package com.ca.contorller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ca.dto.Interview;
import com.ca.service.Interviewservice;


@WebServlet(name="interview",urlPatterns="/interview")
public class interview extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{

		
		String profile = request.getParameter("profile");
		HttpSession context = request.getSession();
		String n = (String) context.getAttribute("Clogmail");
		Interview shortlist = new Interview(profile,n);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Interviewservice service = new Interviewservice();
		try{
			boolean result = service.checkmail(shortlist);
			out.println("<html>");
			 out.println("<head>");		
			 out.println("<title>Registration Successful</title>");		
			 out.println("</head>");
			 out.println("<body>");
			 out.println("<center>");
			 if(result){
				 out.println("<h1>Thanks for Registering with us :</h1>");
				 out.println("To login with new UserId and Password<a href=views/company/clogin.jsp>Click here</a>");
			 }else{
				 out.println("<h1>Registration Failed</h1>");
				 out.println("To try again<a href=views/company/cregister.jsp>Click here</a>");
			 }
			 out.println("</center>");
			 out.println("</body>");
			 out.println("</html>");
		 } finally {		
			 out.close();
		 }
				
	}
}
