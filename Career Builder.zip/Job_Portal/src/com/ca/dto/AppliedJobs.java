package com.ca.dto;
 
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="Applied_jobs")
public class AppliedJobs {

	@Id
	@GeneratedValue
	private long id=0;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="User_Id")
	private Registration registration;
	

	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Post_Id")
	private JobPost post;
	
	public AppliedJobs()
	{}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Registration getRegistration() {
		return registration;
	}

	public void setRegistration(Registration registration) {
		this.registration = registration;
	}

	public JobPost getPost() {
		return post;
	}

	public void setPost(JobPost post) {
		this.post = post;
	}


}