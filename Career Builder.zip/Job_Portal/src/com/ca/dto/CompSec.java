package com.ca.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name="Company_Security")
public class CompSec{

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="question_id")
	private long qid=0;
	@Column(name="Security_Question_1")
	private String SQ1;
	@Column(name="Answer_1")
	private String Ans1;
	@Column(name="Security_Question_2")
	private String SQ2;
	@Column(name="Answer_2")
	private String Ans2;
	@OneToOne
	private Compreg reg;

	@Transient
	private String cmail;
	
	@OneToMany(mappedBy="reg")
	private Set<Interview> shortlist = new HashSet<Interview>();
	
	
	
	public Set<Interview> getShortlist() {
		return shortlist;
	}

	public void setShortlist(Set<Interview> shortlist) {
		this.shortlist = shortlist;
	}

	public CompSec()
	{
		
	}
	
	public CompSec(String SQ1,String Ans1,String SQ2 ,String Ans2,String cmail)
	{
		this.SQ1=SQ1;
		this.Ans1=Ans1;
		this.SQ2=SQ2;
		this.Ans2=Ans2;
		this.cmail=cmail;
	}
	
	
	
	public long getQid() {
		return qid;
	}

	public void setQid(long qid) {
		this.qid = qid;
	}

	public String getCmail() {
		return cmail;
	}

	public void setCmail(String cmail) {
		this.cmail = cmail;
	}

	public Compreg getReg() {
		return reg;
	}
	public void setReg(Compreg reg) {
		this.reg = reg;
	}
	public String getSQ1() {
		return SQ1;
	}
	public void setSQ1(String sQ1) {
		SQ1 = sQ1;
	}
	public String getAns1() {
		return Ans1;
	}
	public void setAns1(String ans1) {
		Ans1 = ans1;
	}
	public String getSQ2() {
		return SQ2;
	}
	public void setSQ2(String sQ2) {
		SQ2 = sQ2;
	}
	public String getAns2() {
		return Ans2;
	}
	public void setAns2(String ans2) {
		Ans2 = ans2;
	}
	
	
	
	
}
