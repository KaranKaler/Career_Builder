package com.ca.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="Company_Info")
public class CompanyInfo {

	@Id
	@GeneratedValue
	private long Id=0;
	
	
	@Lob
	@Column(name="Information")
	private String Info;

	@OneToOne
	@JoinColumn(name="Email_Id", referencedColumnName="EmailId")
	private Compreg reg;
	
	
	@Transient
	private String cmail;
	
	
	public CompanyInfo()
	{
		
	}
	
	public CompanyInfo(String Info,String cmail)
	{
		this.Info=Info;
		this.cmail=cmail;
	}	
	public String getCmail() {
		return cmail;
	}

	public void setCmail(String cmail) {
		this.cmail = cmail;
	}

	public long getId() {
		return Id;
	}
	public void setId(long id) {
		Id = id;
	}
	public Compreg getReg() {
		return reg;
	}
	public void setReg(Compreg reg) {
		this.reg = reg;
	}
	public String getInfo() {
		return Info;
	}
	public void setInfo(String info) {
		Info = info;
	}
}
