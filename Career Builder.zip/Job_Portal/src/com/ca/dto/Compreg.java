package com.ca.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Company_Registration")
public class Compreg {

	@Id
	@Column(name="EmailId")
	private String EmailId;
			
	@Column(name="password")
	private String password;
	
	@Column(name="Name_Of_Company")
	private String name;
	
	@Column(name="State")
	private String state;
	
	@Column(name="City")
	private String City;
	
	@Column(name="Contact_Person")
	private String ContactPerson;
	
	@Column(name="Pin_Code")
	private String Pin;
	
	@Column(name="Mobile_Number")
	private String Contactno;
	
	@Column(name="Industry")
	private String Industry;
	
	@OneToMany(fetch = FetchType.EAGER,mappedBy="reg")
	private Set<Interview> shortlist = new HashSet<Interview>();
	
	public Compreg()
	{
		
	}
	
	public Compreg(String EmailId, String password, String name, String State, String City, String ContactPerson, String Pin, String Contactno, String Industry)
	{
		
		this.EmailId=EmailId;
		this.password=password;
		this.name=name;
		this.state=State;
		this.City=City;
		this.ContactPerson=ContactPerson;
		this.Contactno=Contactno;
		this.Pin=Pin;
		this.Industry=Industry;
		
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getContactPerson() {
		return ContactPerson;
	}

	public void setContactPerson(String contactPerson) {
		ContactPerson = contactPerson;
	}

	public String getPin() {
		return Pin;
	}

	public void setPin(String pin) {
		Pin = pin;
	}

	public String getContactno() {
		return Contactno;
	}

	public void setContactno(String contactno) {
		Contactno = contactno;
	}

	public String getIndustry() {
		return Industry;
	}

	public void setIndustry(String industry) {
		Industry = industry;
	}

	public Set<Interview> getShortlist() {
		return shortlist;
	}

	public void setShortlist(Set<Interview> shortlist) {
		this.shortlist = shortlist;
	}
	
}