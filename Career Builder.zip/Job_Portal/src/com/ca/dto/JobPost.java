package com.ca.dto;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
@Table(name="Job_Postings")
public class JobPost {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Job_Id")
	private long PostId=0; 
	
	@Column(name="Profile")
	private String Profile; 
	
	@Column(name="Company_Name")
	private String Company; 
	
	@Column(name="Place")
	private String Place; 
	
	@Column(name="Experience")
	private String Experience; 
	
	@Column(name="Salary")
	private String Salary; 
	
	@Column(name="Pin_Code")
	private String Pin; 
	
	@Column(name="Date_Of_Posting")
	private Date date; 
	
	@Lob
	@Column(name="Description")
	private String Description; 
	
	@Column(name="Industry_Type")
	private String Industry; 
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Compreg reg; 
	
	@Transient
	private String cmail;
	
	@OneToMany(fetch = FetchType.EAGER,mappedBy= "post")
	private Set<AppliedJobs> jobs = new HashSet<AppliedJobs>();
	
	

	
	
	public Set<AppliedJobs> getJobs() {
		return jobs;
	}

	public void setJobs(Set<AppliedJobs> jobs) {
		this.jobs = jobs;
	}

	public JobPost()
	{}
	
	public JobPost(String Profile,String Company,String Place,String Experience,String Salary,String Pin,String Description,String Industry,String cmail)
	{
		this.Profile=Profile;
		this.Company=Company;
		this.Place=Place;
		this.Experience=Experience;
		this.Salary=Salary;
		this.Pin=Pin;
		this.Description=Description;
		this.Industry=Industry;
		this.cmail=cmail;
	}
	
	
		
	
	public String getCmail() {
		return cmail;
	}

	public void setCmail(String cmail) {
		this.cmail = cmail;
	}

	public Compreg getReg() {
		return reg;
	}
	public void setReg(Compreg reg) {
		this.reg = reg;
	}
	
	public long getPostId() {
		return PostId;
	}

	public void setPostId(long postId) {
		PostId = postId;
	}

	public String getProfile() {
		return Profile;
	}
	public void setProfile(String profile) {
		Profile = profile;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		Company = company;
	}
	public String getPlace() {
		return Place;
	}
	public void setPlace(String place) {
		Place = place;
	}
	public String getExperience() {
		return Experience;
	}
	public void setExperience(String experience) {
		Experience = experience;
	}
	public String getSalary() {
		return Salary;
	}
	public void setSalary(String salary) {
		Salary = salary;
	}
	public String getPin() {
		return Pin;
	}
	public void setPin(String pin) {
		Pin = pin;
	}
	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getIndustry() {
		return Industry;
	}
	public void setIndustry(String industry) {
		Industry = industry;
	}


}