package com.ca.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table (name="Student_Profile")
public class Profile {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long profileid=0;
	
	@Column(name="Date_Of_Birth")
	private String DOB;
	
	@Column(name="Qualification")
	private String Qual;
	
	@Column(name="College_Name")
	private String College;
	
	@Column(name="Year_Passing")
	private String Year;
	
	@Column(name="University_Name")
	private String University;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Email_Id", referencedColumnName="EmailId")
	private Registration register;
	
	@Transient
	private String email;

	
	
	public Profile()
	{
		
	}
	
	public Profile(String DOB, String Qual, String College, String Year, String University,String email)
	{
		this.DOB=DOB;
		this.Qual=Qual;
		this.College=College;
		this.Year=Year;
		this.University=University;
		this.email=email;
	}
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	
	public Profile(Registration register)
	{
		this.register=register;
	}

	
	
	
	

	public Registration getRegister() {
		return register;
	}

	public void setRegister(Registration register) {
		this.register = register;
	}

	public long getProfileid() {
		return profileid;
	}
	public void setProfileid(long profileid) {
		this.profileid = profileid;
	}
	
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getQual() {
		return Qual;
	}
	public void setQual(String qual) {
		Qual = qual;
	}
	public String getCollege() {
		return College;
	}
	public void setCollege(String college) {
		College = college;
	}
	public String getYear() {
		return Year;
	}
	public void setYear(String year) {
		Year = year;
	}
	public String getUniversity() {
		return University;
	}
	public void setUniversity(String university) {
		University = university;
	}
}