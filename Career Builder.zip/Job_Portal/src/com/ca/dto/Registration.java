package com.ca.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Registration")
public class Registration {

	@Id
	@Column(name="EmailId")
	private String EmailId;
	
	@Column(name="First_Name")
	private String FirstName;
	
	@Column(name="Last_Name")
	private String LastName; 
	
	@Column(name="Password")
	private String Password; 
	
	@Column(name="Location")
	private String Location; 
	
	@Column(name="Skills")
	private String Skills; 
	
	@Column(name="Gender")
	private String Gender; 
	
	@Column(name="Industry_type")
	private String Industry;
	
	@OneToMany(fetch = FetchType.EAGER,mappedBy="registration")
	private Set<AppliedJobs> applied = new HashSet<AppliedJobs>();

	@OneToMany(fetch = FetchType.EAGER,mappedBy="register")
	private Set<Interview> shortlist = new HashSet<Interview>();
	

	public Set<Interview> getShortlist() {
		return shortlist;
	}


	public void setShortlist(Set<Interview> shortlist) {
		this.shortlist = shortlist;
	}


	public Set<AppliedJobs> getApplied() {
		return applied;
	}


	public void setApplied(Set<AppliedJobs> applied) {
		this.applied = applied;
	}


	public Registration()
	{
		
	}
	
	
	public Registration(String EmailId, String FirstName, String LastName, String Password, String Location, String Skill, String Gender, String Industry){
		
		this.EmailId=EmailId;
		this.FirstName=FirstName;
		this.LastName=LastName;
		this.Password=Password;
		this.Location=Location;
		this.Skills=Skill;
		this.Gender=Gender;
		this.Industry=Industry;
		
	}
	
	

	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getSkills() {
		return Skills;
	}
	public void setSkills(String skills) {
		Skills = skills;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getIndustry() {
		return Industry;
	}
	public void setIndustry(String industry) {
		Industry = industry;
	}
}
