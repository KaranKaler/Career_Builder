package com.ca.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.AppliedJobs;


public class AppliedService {
	
	public boolean setupdate(AppliedJobs jobs)
	{
		Session session = HIbernateUtil.openSession();
		
		{
			Transaction tx = null;	
		try {
			 tx = session.getTransaction();
			 tx.begin();
			 session.save(jobs);
			 tx.commit();
		}
		catch (Exception e) 
		{
			 if (tx != null) 
			 {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } 
		finally
		 {
			 session.close();
		 }	
		return true;
		}
	
	}


}
