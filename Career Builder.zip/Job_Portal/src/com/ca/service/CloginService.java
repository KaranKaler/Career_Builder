package com.ca.service;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.Compreg;

public class CloginService {


	public boolean authenticateUser(String EmailId, String password) {
	       Compreg reg = getUserByUserId(EmailId);          
	        if(reg!=null && reg.getEmailId().equals(EmailId) && reg.getPassword().equals(password)){
	            return true;
	        }else{ 
	            return false;
	        }
	    }

	    public Compreg getUserByUserId(String EmailId) {
	        Session session = HIbernateUtil.openSession();
	        Transaction tx = null;
	        Compreg reg = null;
	        try {
	            tx = session.getTransaction();
	            tx.begin();
	            Query query = session.createQuery("from Compreg where EmailId='"+EmailId+"'");
	            reg = (Compreg)query.uniqueResult();
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	        return reg;
	    }
	    
	    public List<Compreg> getListOfUsers(){
	        List<Compreg> list = new ArrayList<Compreg>();
	        Session session = HIbernateUtil.openSession();
	        Transaction tx = null;        
	        try {
	            tx = session.getTransaction();
	            tx.begin();
	            list = session.createQuery("from Compreg").list();                        
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	        return  list;
	    }
	
	
}
