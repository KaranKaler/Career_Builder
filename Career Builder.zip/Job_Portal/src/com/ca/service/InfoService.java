package com.ca.service;

import java.util.List; 
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.CompanyInfo;



public class InfoService {

	
	public boolean setupdate(CompanyInfo info)
	{
		Session session = HIbernateUtil.openSession();
		
		{
			Transaction tx = null;	
		try {
			 tx = session.getTransaction();
			 tx.begin();
			 session.save(info);
			 tx.commit();
		}
		catch (Exception e) 
		{
			 if (tx != null) 
			 {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } 
		finally
		 {
			 session.close();
		 }	
		return true;
		}
	
	}
	
	
	public boolean  checkmail(CompanyInfo info1)
	{
		long value; 
		Session session = HIbernateUtil.openSession();
		Transaction tx = null;
		 try{
			 tx = session.getTransaction();
			 tx.begin();
			 String n = info1.getCmail();
			 System.out.println("email "+n);
			 Query query = session.createQuery("select Id from CompanyInfo where reg='"+n+"'");
			 List<Long> list = query.list();
			 if(list != null && list.size() >0 )
			 {
				value=list.get(0);
				System.out.println("value "+value);
				CompanyInfo info = (CompanyInfo) session.get(CompanyInfo.class, value);
				info.setInfo(info1.getInfo());
				session.update(info);
				
				return true;
			 }
			 
		 }
			catch (Exception e) 
			{
				 if (tx != null) 
				 {
					 tx.rollback();
					 System.out.println("cannot update the data"+e);
				 }
				 e.printStackTrace();
			 } 
			finally
			 {
				tx.commit();
				session.close();
			 }
		
		return false;
			 
		 
	}	
}
