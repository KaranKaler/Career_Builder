package com.ca.service;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.Interview;
import com.ca.dto.Registration;

public class Interviewservice {
	
	public boolean setupdate(Interview shortlist)
	{
Session session = HIbernateUtil.openSession();
		
		{
			Transaction tx = null;	
		try {
			 tx = session.getTransaction();
			 tx.begin();
			 session.save(shortlist);
			 tx.commit();
		}
		catch (Exception e) 
		{
			 if (tx != null) 
			 {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } 
		finally
		 {
			 session.close();
		 }	
		return true;
		}
	}


	
	
	public boolean  checkmail(Interview shortlist1)
	{
		
		long value; 
		Session session = HIbernateUtil.openSession();
		Transaction tx = null;
		 try{
			 tx = session.getTransaction();
			 tx.begin();
			 String n = shortlist1.getCmail();
			 System.out.println("email "+n);
			 Registration register =(Registration) session.get(Registration.class, "mrkalerhere@gmail.com");
			 Query query = session.createQuery("select SNO from Interview where reg='"+n+"'");
			 List<Long> list = query.list();
			 if(list != null && list.size() >0 )
			 {
				 value=list.get(0);
					System.out.println("value "+value);
					Interview shortlist = (Interview) session.get(Interview.class, value);
					shortlist.setProfile(shortlist1.getProfile());
					shortlist.setProfile(shortlist1.getProfile());
					
			 }
		
		 }
		 catch(Exception e)
		 {
			 System.out.println("exception raised is "+e);
		 }
		finally {
			session.close();
		}
		return false;
	}
}
