package com.ca.service;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.Registration;

public class LoginService {

	 public boolean authenticateUser(String EmailId, String password) {
	       Registration register = getUserByUserId(EmailId);          
	        if(register!=null && register.getEmailId().equals(EmailId) && register.getPassword().equals(password)){
	            return true;
	        }else{ 
	            return false;
	        }
	    }

	    public Registration getUserByUserId(String EmailId) {
	        Session session = HIbernateUtil.openSession();
	        Transaction tx = null;
	        Registration register = null;
	        try {
	            tx = session.getTransaction();
	            tx.begin();
	            Query query = session.createQuery("from Registration where EmailId='"+EmailId+"'");
	            register = (Registration)query.uniqueResult();
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	        return register;
	    }
	    
	    public List<Registration> getListOfUsers(){
	        List<Registration> list = new ArrayList<Registration>();
	        Session session = HIbernateUtil.openSession();
	        Transaction tx = null;        
	        try {
	            tx = session.getTransaction();
	            tx.begin();
	            list = session.createQuery("from Registration").list();                        
	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	        return  list;
	    }
	
}
