package com.ca.service;


import java.util.List; 
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.Profile;

public class PService {

	public boolean setupdate(Profile profile)
	{
		Session session = HIbernateUtil.openSession();
		
		{
			Transaction tx = null;	
		try {
			 tx = session.getTransaction();
			 tx.begin();
			 session.save(profile);
			 tx.commit();
		}
		catch (Exception e) 
		{
			 if (tx != null) 
			 {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } 
		finally
		 {
			 session.close();
		 }	
		return true;
		}
	
	}
	
		
	
	public boolean  checkmail(Profile profile1)
	{
		long value;
		Session session = HIbernateUtil.openSession();
		Transaction tx = null;
		 try{
			 tx = session.getTransaction();
			 tx.begin();
			 String n = profile1.getEmail();
			 System.out.println("email "+n);
			 Query query = session.createQuery("select profileid from Profile where register='"+n+"'");
			 List<Long> list = query.list();
			 if(list != null && list.size() >0 )
			 {
				value = list.get(0);
				System.out.println("value "+value);
				Profile profile = (Profile) session.get(Profile.class, value);
				profile.setCollege(profile1.getCollege());
				profile.setDOB(profile1.getDOB());
				profile.setQual(profile1.getQual());
				profile.setUniversity(profile1.getUniversity());
				profile.setYear(profile1.getYear());
				session.update(profile);
				
				return true;
			 }
			 	
		 }
			catch (Exception e) 
			{
				 if (tx != null) 
				 {
					 tx.rollback();
					 System.out.println("cannot update the data"+e);
				 }
				 e.printStackTrace();
			 } 
			finally
			 {
				tx.commit();
				session.close();
			 }
		
		return false;
		}
	
	
	
}
		
		
	
		 	
	

