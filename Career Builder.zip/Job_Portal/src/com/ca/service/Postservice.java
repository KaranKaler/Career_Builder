package com.ca.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.Compreg;
import com.ca.dto.JobPost;


public class Postservice {

	public boolean setupdate(JobPost post)
	{
		Session session = HIbernateUtil.openSession();
		
		{
			Transaction tx = null;	
		try {
			 tx = session.getTransaction();
			 tx.begin();
			 session.save(post);
			 tx.commit();
		}
		catch (Exception e) 
		{
			 if (tx != null) 
			 {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } 
		finally
		 {
			 session.close();
		 }	
		return true;
		}
	
	}
	
		
	
	public boolean  checkmail(JobPost post1)
	{
		
		Session session = HIbernateUtil.openSession();
		Transaction tx = null;
		 try{
			 tx = session.getTransaction();
			 tx.begin();
			 String n = post1.getCmail();
			 System.out.println("email "+n);
			 Compreg reg = (Compreg) session.get(Compreg.class, n);
				JobPost post = new JobPost();
				post.setProfile(post1.getProfile());
				post.setCompany(post1.getCompany());
				post.setPlace(post1.getPlace());
				post.setExperience(post1.getExperience());
				post.setSalary(post1.getSalary());
				post.setPin(post1.getPin());
				post.setDescription(post1.getDescription());
				post.setIndustry(post1.getIndustry());
				post.setReg(reg);
				session.save(post);
				
				return true;
			
			 	
		 }
			catch (Exception e) 
			{
				 if (tx != null) 
				 {
					 tx.rollback();
					 System.out.println("cannot update the data"+e);
				 }
				 e.printStackTrace();
			 } 
			finally
			 {
				tx.commit();
				session.close();
			 }
		
		return false;
	
   }
}
