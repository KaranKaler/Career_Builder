package com.ca.service;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.CompSec;

public class SecService {

	public boolean setupdate(CompSec sec)
	{
		Session session = HIbernateUtil.openSession();
		
		{
			Transaction tx = null;	
		try {
			 tx = session.getTransaction();
			 tx.begin();
			 session.save(sec);
			 tx.commit();
		}
		catch (Exception e) 
		{
			 if (tx != null) 
			 {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } 
		finally
		 {
			 session.close();
		 }	
		return true;
		}
	
	}
	
		
	
	public boolean  checkmail(CompSec sec1)
	{
		long value; 
		Session session = HIbernateUtil.openSession();
		Transaction tx = null;
		 try{
			 tx = session.getTransaction();
			 tx.begin();
			 String n = sec1.getCmail();
			 System.out.println("Email "+n);
			 Query query = session.createQuery("select qid from CompSec where reg='"+n+"'");
			 List<Long> list = query.list();
			 if(list != null && list.size() >0 )
			 {
				value=list.get(0);
				System.out.println("value "+value);
				CompSec sec = (CompSec) session.get(CompSec.class, value);
				sec.setSQ1(sec1.getSQ1());
				sec.setAns1(sec1.getAns1());
				sec.setSQ2(sec1.getSQ2());
				sec.setAns2(sec1.getAns2());
				session.update(sec);
				return true;
			 }
			 	
		 }
			catch (Exception e) 
			{
				 if (tx != null) 
				 {
					 tx.rollback();
					 System.out.println("cannot update the data"+e);
				 }
				 e.printStackTrace();
			 } 
			finally
			 {
				tx.commit();
				session.close();
			 }
		
		return false;
			 
		 
	}
	
	
	
	
	
}
