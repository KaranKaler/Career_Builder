package com.ca.service;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ca.HibernateUtil.HIbernateUtil;
import com.ca.dto.Interview;


public class shortlistservice {

	
	public String getlistusers(Interview view)
	{
		
		 Session session = HIbernateUtil.openSession();
		 Transaction tx = null;
		 try{
			 tx = session.getTransaction();
			 tx.begin();
			 Query query = session.createQuery("Select EmailId from Registration where Industry=''");
			 List<String> list = query.list();
			 
			 
			 
			 
		 }
		catch(Exception ex)
		 {
			
		 }
		
		return null;
		 
}
}