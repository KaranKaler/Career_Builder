package com.ca.test;

import org.hibernate.Session;

import com.ca.HibernateUtil.HIbernateUtil;

public class TestApp {

	
	public static void main(String[] args) {
        Session session = null;
        try {
            session = HIbernateUtil.openSession();
            if (session == null) {
                throw new IllegalArgumentException("Session could not be created ");
            } else {
                System.out.println("tables are created");
            }
        } catch (Exception ex) {
            System.out.println("" + ex.getMessage());
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
}